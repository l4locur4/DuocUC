/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exp3_s8_eduardo_de_ferrari;

/**
 *Actividad Sumativa 3
 * @author Eduardo De Ferrari Dupuis
 * Semana 8
 * Tema: Programando Arreglos, Listas y Funciones
 * Fecha de entrega: 30 de Septiembre
 */

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


public class Exp3_S8_Eduardo_De_Ferrari {
    
    //Arreglos globales
    public static String[]menu={"Comprar entrada","Modificar entrada existente","Salir","Finalizar compra","Realizar otra compra"};//menu principal
    public static String[][] asientos = {
                { "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "A10", },
                { "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", },
                { "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", },
                { "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", },
                { "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "E10", },
                { "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", },
                { "G1", "G2", "G3", "G4", "G5", "G6", "G7", "G8", "G9", "G10", },
                { "H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8", "H9", "H10", },
                { "I1", "I2", "I3", "I4", "I5", "I6", "I7", "I8", "I9", "I10", },
                { "J1", "J2", "J3", "J4", "J5", "J6", "J7", "J8", "J9", "J10", },
                { "K1", "K2", "K3", "K4", "K5", "K6", "K7", "K8", "K9", "K10", },
                { "L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9", "L10", },
                { "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", },
        };//asientos
    public static String[]cliente={"General","Estudiante","Tercera Edad"};//Tipo de cliente
    public static String[]tipoAsiento={"VIP","Platea","Balcon"};
    public static Double[]precios={20000.0,15000.0,10000.0};
    
    //Listas
    public static List<String>reservas=new ArrayList<>();
    public static List<String>ventas=new ArrayList<>();
    public static List<String>IDcliente=new ArrayList<>();
    public static List<String>Tarifa=new ArrayList<>();
    public static List<String>Asiento=new ArrayList<>();
    public static List<Double>Precio=new ArrayList<>();
    public static List<Integer>IDreserva=new ArrayList<>();
    
    static String asiento;
    static boolean CONTINUAR=true;//Para ejecutar menu
    static boolean DISPONIBLE=true;//Para ver disponibilidad de asientos
    static int i=0; // contador de filas
    static int j=0; // contador de columnas
    static int fila=0;
    static int columna=0;
    static int modificar=0;
    static int compra=0;
    static double precio=0;
    static double preciototal=0;
    static String tipodeasiento;
    static String nombre;
    static String apellido;
    
    

    
    
    public static void main(String[] args) {
        int opcion=0;
        Scanner scanner=new Scanner(System.in);
        System.out.println("===== BIENVENIDO AL TEATRO MORO =====");
        
        do{
            System.out.println("\n=== MENU ===");
            for(i=0;i<3;i++){ 
                System.out.println((i+1)+". "+menu[i]); 
            }
            if(scanner.hasNextInt()){
                opcion=scanner.nextInt();
                switch(opcion){
                    case 1:
                        VentaDeEntradas(scanner);
                        break;
                    case 2:
                        ModificarVenta(scanner);
                        break;
                    case 3: 
                        CONTINUAR=false;
                        break;
                    default:
                        System.out.println("Opcion no valida.");
                }
            }else{
                System.out.println("Opcion no valida.");
            }
        }while(CONTINUAR);    
    }
    
    public static void seleccionarAsiento(Scanner scanner){ 
        do {
            // Aquí aparecen los asientos disponibles
            System.out.println("\nAsientos disponibles. Los asientos marcados con XX estan ocupados.");
            System.out.println("\n---------ASIENTOS VIP---------");
            for (i = 0; i < 3; i++) {
                for (j = 0; j < asientos[i].length; j++) {
                    System.out.print(asientos[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println("--------ASIENTOS PLATEA-------");
            for (i = 3; i < 7; i++) {
                for (j = 0; j < asientos[i].length; j++) {
                    System.out.print(asientos[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println("-------ASIENTOS BALCON--------");
            for (i = 7; i < 13; i++) {
                for (j = 0; j < asientos[i].length; j++) {
                    System.out.print(asientos[i][j] + " ");
                }
                System.out.println();
            }
            
            //El usuario selecciona el asiento
            System.out.println("\nSeleccione la fila de su asiento.");
            System.out.println("1.A 2.B 3.C 4.D 5.E 6.F 7.G 8.H 9.I");
            System.out.println("       10.J 11.K 12.L 13.M");
            
            int indexi=-1;
            int indexj=-1;
            
            do{
                if(scanner.hasNextInt()){
                    fila=scanner.nextInt();
                    if(fila<1||fila>13){
                        System.out.println("Opcion no valida. Vuelve a ingresar la fila.");
                    }
                }else{
                    System.out.println("Opcion no valida. Vuelve a ingresar la fila.");
                    
                }
            }while(fila<1||fila>13);
            
            System.out.println("Seleccione el número de asiento del 1 al 10:");
            do {
                if (scanner.hasNextInt()) {
                    columna = scanner.nextInt();
                    if (columna < 1 || columna > 10) {
                        System.out.println("Ingrese un número de asiento válido");
                    }
                } else {
                    System.out.println("Ingrese un número entero del 1 al 10.");
                    scanner.next();
                }
            } while (columna < 1 || columna > 10);
            
            asiento=asientos[fila-1][columna-1];
            Asiento.add(asiento);
            
             for (i = 0; i < asientos.length; i++) {
                for (j = 0; j < asientos[i].length; j++) {
                    if (asientos[i][j].equals(asiento)) {
                        indexi = i;
                        indexj = j;
                        break;
                    }
                }
                if (indexj != -1) {
                    break;
                }
            }
            if (indexi != -1 && indexj != -1 && !asientos[indexi][indexj].equals("XX")) {
                System.out.println("Asiento disponible");
                DISPONIBLE=true;
                if(i<3){
                    precio=precios[0];
                    tipodeasiento=tipoAsiento[0];
                }else if(i>=3&&i<7){
                    precio=precios[1];
                    tipodeasiento=tipoAsiento[1];
                }else{
                    precio=precios[2];
                    tipodeasiento=tipoAsiento[2];
                }
                asientos[indexi][indexj] = "XX";
                
                

            } else {
                System.out.println("\nAsiento NO disponible.");
                DISPONIBLE=false;
            }
        }while(DISPONIBLE==false); 
        
    }
    
    public static void VentaDeEntradas(Scanner scanner){
        
        int tarifa=0;
        int finalizarcompra=0;
        Scanner nom=new Scanner(System.in);
        Scanner ape=new Scanner(System.in);
        
        do{
            System.out.println("Seleccione su tarifa: ");

            for(i=0;i<3;i++){
                System.out.println((i+1)+". "+cliente[i]);
            }
            do{
                if(scanner.hasNextInt()){
                    tarifa=scanner.nextInt();
                    switch(tarifa){
                        case 1:
                            seleccionarAsiento(scanner);
                            Tarifa.add(cliente[0]);
                            break;
                        case 2:
                            seleccionarAsiento(scanner);
                            Tarifa.add(cliente[1]);
                            precio=precio*0.9;
                            break;
                        case 3:
                            seleccionarAsiento(scanner);
                            Tarifa.add(cliente[2]);
                            precio=precio*0.85;
                            break;
                        default:
                            System.out.println("Opcion no valida.");
                    }
                }else{
                    System.out.println("Opcion no valida");
                }
                
                Precio.add(precio);

                System.out.println("Ingrese su nombre: ");
                nombre=nom.nextLine();

                System.out.println("Ingrese su apellido: ");
                apellido=ape.nextLine();
                IDcliente.add(nombre+" "+apellido);
                
                if(modificar!=0){
                    reservas.set(modificar-1,"ID Reserva: "+(compra+1)+" ID Cliente: "+IDcliente.get(compra)+ " Asiento: "+Asiento.get(compra)+" "+tipodeasiento+" Tarifa: "+Tarifa.get(compra) +" Precio: $"+Precio.get(compra));
                    preciototal=0;
                    Precio.remove(modificar-1);

                }else{
                    reservas.add("ID Reserva: "+(compra+1)+" ID Cliente: "+IDcliente.get(compra)+ " Asiento: "+asiento+" "+tipodeasiento+" Tarifa: "+Tarifa.get(compra) +" Precio: $"+Precio.get(compra));

                }
                               
                compra=reservas.size();
               
            }while(tarifa<1||tarifa>3);  
            
  

            System.out.println("===== RESUMEN DE RESERVA =====");
            for(i=0;i<reservas.size();i++){
                System.out.println(reservas.get(i));
            }
            
            for(compra=0;compra<reservas.size();compra++){
                preciototal+=Precio.get(compra);
                
            }
            System.out.println("El precio total es: $"+preciototal);
            System.out.println(Precio);
            

            System.out.println("\nDeseas concretar la compra?");

            for(i=0;i<3;i++){ 
                    System.out.println((i+1)+". "+menu[4-i]); 
                }

            do{
                if(scanner.hasNextInt()){
                    finalizarcompra=scanner.nextInt();
                    if(finalizarcompra<1||finalizarcompra>3){
                        System.out.println("Opcion no valida");
                    }else if(finalizarcompra==3){
                        System.out.println("\nSu reserva quedo registrado en el sistema hasta que se concretre la compra. Puedes comprar mas entradas, modificar las ventas existentes o salir.");
                        System.out.println("En caso de salir, se perderan las reservas efectuadas anteriormente.");
                    }else if(finalizarcompra==1){
                        preciototal=0;
                    }

                }else{
                    System.out.println("Opcion no valida");
                }
            }while(finalizarcompra<1||finalizarcompra>3);
        }while(finalizarcompra==1);
        
        
        if(finalizarcompra==2){
            imprimirBoleta(scanner);
            CONTINUAR=false;
            System.exit(0);
        }
        
    }
    
    public static void ModificarVenta(Scanner scanner){
        
        int cambiar=0;
        int finalizarcompra=0;
        
        System.out.println("===== RESUMEN DE RESERVA =====");
        for(i=0;i<reservas.size();i++){
            System.out.println(reservas.get(i));
        } 
        
        System.out.println("\nCual entrada desea modificar?");
        do{
            if(scanner.hasNextInt()){
                modificar=scanner.nextInt();
                if(modificar<0||modificar>reservas.size()){
                    System.out.println("Entrada invalida o inexistente.");
                }
            }else{
                System.out.println("Entrada invalida o inexistente.");
            }
        }while(modificar<0||modificar>reservas.size());
        
        System.out.println("Que modificacion desea realizar?");
        System.out.println("1.Remplazar 2.Eliminar");
        
        do{
            if(scanner.hasNextInt()){
                cambiar=scanner.nextInt();
                switch(cambiar){
                    case 1:
                        VentaDeEntradas(scanner);
                        break;
                    case 2:
                        reservas.remove(modificar-1);
                        preciototal=preciototal-Precio.get(modificar-1);
                       
                        break;
                    default:
                        System.out.println("Opcion invalida");
                        break;
                        
                }
            }else{
                System.out.println("Opcion invalida");
            }
        }while(cambiar<0||cambiar>2);
        
        
        System.out.println("===== RESUMEN DE RESERVA =====");
        for(i=0;i<reservas.size();i++){
            System.out.println(reservas.get(i));
        }
        System.out.println("El precio total es: $"+preciototal);
            
        
        System.out.println("Deseas concretar la compra?");
        System.out.println("1.Si  2.No");

     do{
            if(scanner.hasNextInt()){
                finalizarcompra=scanner.nextInt();
                if(finalizarcompra<0||finalizarcompra>2){
                    System.out.println("Opcion no valida");
                }else if(finalizarcompra==1){
                    imprimirBoleta(scanner);
                    CONTINUAR=false;
                }

            }else{
                System.out.println("Opcion no valida");
            }
        }while(finalizarcompra<0||finalizarcompra>2);      
    }

    public static void imprimirBoleta(Scanner scanner) {
        // Implementar funcionalidad de impresión de boleta si es necesario
        System.out.println("===========================================================================");
        System.out.println("                                 TEATRO MORO                               ");
        System.out.println("===========================================================================");
        for (i = 0; i < reservas.size(); i++) {
            ventas.add("ID Venta: "+(i)+" ID Cliente: "+IDcliente.get(i)+ " Asiento: "+Asiento.get(i)+" "+tipodeasiento+" Tarifa: "+Tarifa.get(i) +" Precio: $"+Precio.get(i));
            System.out.println(ventas.get(i));
        }
        System.out.println("___________________________________________________________________________");
      
        System.out.println("El precio total es: $"+preciototal);
        
        System.out.println("===========================================================================");
        System.out.println("       MUCHAS GRACIAS POR SU COMPRA Y QUE DISFRUTE DE LA FUNCION           ");
        System.out.println("===========================================================================");
        CONTINUAR=false;
    }    
    
}